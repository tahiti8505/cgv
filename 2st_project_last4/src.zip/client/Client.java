package client;

import controller.Controller;

public class Client {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controller conn = new Controller();
		conn.startApp();
	}
}