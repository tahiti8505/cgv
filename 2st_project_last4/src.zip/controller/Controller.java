package controller;

import java.util.ArrayList;

import model.CgvDAO;
import model.CgvVO;
import model.MemberDAO;
import model.MemberVO;
import view.View;

public class Controller {
	MemberDAO mDAO;
	CgvDAO cDAO;
	View view;
	CgvVO vo;
	public Controller() {
		mDAO = new MemberDAO();
		cDAO = new CgvDAO();
		view = new View();
		vo = new CgvVO();
		if(!(cDAO.hasSample(vo))) {
			Crawling.sample();
		}
		else {
			System.out.println("로그 : 샘플 데이터 존재");
		}
	}
	public void startApp() {
		ArrayList<CgvVO> datas = new ArrayList<CgvVO>();
		while(true) {
			view.loginView();
			if(View.action==1) { 		// 로그인 
				MemberVO vo = new MemberVO();
				vo = view.login(); 		// vo에 view.login()에서 받은 id와 pw을 담는다.
				MemberVO data = mDAO.login(vo);	// MemberDAO의 login메서드로 해당 회원의 정보를 return
				if(data==null) {		// 그에 맞는 객체가 존재하지 않으면 로그인 실패
					view.logInF();
					continue;
				}
				view.logInT();

				while(true) {
					if(data.getMname()==null) { // 회원 탈퇴 후 name을 갖지 않는다면 초기화면으로 돌아간다.
						break;
					}
					view.startView();
					if(View.action==1) {        // 영화 목록
						CgvVO cvo = new CgvVO();
						view.movieList(cDAO.selectAll(cvo)); // 전체 영화 목록을 출력해주는 selectAll() & movieList() 메서드 
						continue;
					}
					else if(View.action==2) {   // 영화 검색
						CgvVO cvo = new CgvVO();

						cvo = view.searchView();             // view의 serachView() 메서드를 사용해 검색하고싶은 영화 제목과 장르를 받는다.
						view.movieList(cDAO.selectAll(cvo));
						datas=cDAO.selectAll(cvo);			 // 해당 검색결과를 ArrayList에 담는다.
						int num=0;
						while(true) {
							if(datas.size()==0) {		 // 검색결과가 없을시(datas.size()==0) 문구 출력 후 while문을 빠져나간다. 
								view.movieX();
								break;
							}
							view.mSelect();				 
							num = view.inputInt();			// 예매할 영화 번호를 받는다. 
							CgvVO cvo1 = new CgvVO();
							if(num>datas.size() || num<1) { // 범위에 따른 유효성 검사
								System.out.println("범위외 입력입니다.");
								continue;
							}
							cvo1.setCid(datas.get(num-1).getCid()); // 검색 결과가 담긴 리스트에서 사용자의 입력값-1에 해당하는 영화의 cid를 객체에 저장
							if(view.ticket()) {						// 예매를 계속 진행할 것인지에 대해 묻는 메서드
								if(cDAO.update(cvo1)) {				// 해당 영화의 예매 횟수에 대해 update 진행
									view.ticketT();
									MemberVO vo1 = new MemberVO();
									vo1.setMbook(datas.get(num-1).getTitle());  // 로그인한 사람의 최근예약영화에 예매 영화의 제목을 저장한다.
									System.out.println(vo1.getMbook());
									System.out.println(data.getMid());
									vo1.setMid(data.getMid());
									if(!(mDAO.update(vo1))) {
										System.out.println(" 로그 : 저장실패");
									}
									else {
										System.out.println(" 로그 : 최근영화 저장 완료");
									}
									break;
								}
							}
						} 
					}
					else if(View.action==3) {

						while(true) {
							view.myPageView();
							view.inputInt();
							if(View.i==1) {				// 마이페이지
								System.out.println(data);
								MemberVO data1 = new MemberVO();
								data1.setMid(data.getMid());
								data1 = mDAO.selectOne(data1);
								view.myPage(data1);		// 로그인 객체에 담긴 정보를 모두 보여준다.
								continue;
							}
							else if(View.i==2) {
								String ans = view.deleteMember();	// 삭제 여부에 대한 물음을 String ans에 담는다.
								if(ans.equals("Y")) {
									data = view.login();			// view.login()을 통해 삭제하는 계정의 ID와 PW를 확인
									mDAO.delete(data);				// 계정 삭제 후 while문을 빠져나간다. 
									view.deleteT();
									break;
								}
								view.deleteF();
								continue;
							}
							else if(View.i==3){
								view.backpage();
								break;
							}
						}
					}
					else if(View.action==4) {						// 로그아웃
						view.logOutS();
						break;
					}
				}
			}
			else if(View.action==2) {								// 회원가입
				MemberVO vo = new MemberVO();
				vo = view.signUp();									// 회원가입에 필요한 정보를 vo 객체에 담는다.
				while(true) {
					if(mDAO.hasSame(vo)) {							// 중복검사
						System.out.println("로그 : 아이디가 이미 존재");
						view.signF();
						break;
					}
					if(mDAO.user(vo)) {
						view.signT();
						break;
					}
				}
			}
			else if(View.action==3) {								// 프로그램 종료
				break;
			}
		}
	}
}